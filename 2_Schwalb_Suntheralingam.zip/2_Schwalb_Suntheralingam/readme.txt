1. Explanation of the files 

Folder: 2_Schwalb_Suntheralingam
content: datasets used for project
	BSP_DF.csv (Dataset for betfair starting price) #Raw data
	horse_races_venn_diagram.png (Venndiagram of intersection of the horses)
	horses_2019.csv (Dataset with all horses raced in 2019) #Raw data
	horses_image.jpg (horse race image)  
	races_2019.csv (Dataset with all horseraces in 2019)) #Raw data
	references.bib (List of reference)



File: horse_races.Rmd
content: Rmd file created with R Markdown includes also all the code used in the project.

File: horse_races.html
content: html document, report on horse races.

2. Comments
Web links for datasets anchored to the name of datasets in the report. Web links:

Horse racing: https://www.kaggle.com/datasets/hwaitt/horse-racing
Horses and races: https://promo.betfair.com/betfairsp/prices

Authors
Ronald Schwalb, Sujeethan Suntheralingam